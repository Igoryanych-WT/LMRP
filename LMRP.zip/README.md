# LMRP
 Minecraft 1.18+ resource pack for LifeMine server.
